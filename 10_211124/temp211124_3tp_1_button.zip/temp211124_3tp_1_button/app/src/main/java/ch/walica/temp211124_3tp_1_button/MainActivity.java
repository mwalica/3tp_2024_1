package ch.walica.temp211124_3tp_1_button;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnShowHide, btnShowHide2;
    private TextView tvResult1, tvResult2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnShowHide = findViewById(R.id.btnShowHide);
        btnShowHide2 = findViewById(R.id.btnShowHide2);
        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);

        btnShowHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvResult1.getText().toString().isEmpty()) {
                    tvResult1.setText("Tekst się pojawił");
                    btnShowHide.setText(getResources().getString(R.string.btn_text_2));
                } else {
                    tvResult1.setText("");
                    btnShowHide.setText(R.string.btn_text_1);

                }

            }
        });

        btnShowHide2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvResult2.getVisibility() == View.INVISIBLE) {
                    tvResult2.setVisibility(View.VISIBLE);
                    btnShowHide2.setText(R.string.btn_text_2);
                } else {
                    tvResult2.setVisibility(View.INVISIBLE);
                    btnShowHide2.setText(R.string.btn_text_1);
                }
            }
        });

    }
}