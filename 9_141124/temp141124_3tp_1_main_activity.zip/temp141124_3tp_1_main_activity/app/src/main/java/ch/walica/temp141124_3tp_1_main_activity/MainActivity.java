package ch.walica.temp141124_3tp_1_main_activity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private LinearLayout linearLayoutTop;
    private LinearLayout linearLayoutBottom;
    private TextView tvText1;
    private TextView tvText2;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayoutTop = findViewById(R.id.linearLayoutTop);
        linearLayoutBottom = findViewById(R.id.linearLayoutBottom);
        tvText1 = findViewById(R.id.tvText1);
        tvText2 = findViewById(R.id.tvText2);

        linearLayoutTop.setBackgroundColor(randomColor());
        linearLayoutBottom.setBackgroundColor(Color.rgb(0, 28, 240));
        tvText1.setTextColor(getColor(R.color.color1));
        tvText2.setTextColor(randomColor());
        tvText1.setTextSize(42);
        tvText1.setText("Nowy tekst 1");
        tvText2.setText("Nowy tekst 2");

    }

    private int randomColor() {
        int r = random.nextInt(256);
        int g = random.nextInt(50);
        int b = random.nextInt(50);
        return Color.rgb(r, g, b);
    }
}